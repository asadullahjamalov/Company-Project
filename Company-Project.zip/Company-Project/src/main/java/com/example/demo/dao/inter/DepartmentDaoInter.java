package com.example.demo.dao.inter;

import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;

import java.util.List;

public interface DepartmentDaoInter {

    Department getDepartmentById(Long id);

    List<Employee> getEmployeeByDepartmentId(Long id);
}
