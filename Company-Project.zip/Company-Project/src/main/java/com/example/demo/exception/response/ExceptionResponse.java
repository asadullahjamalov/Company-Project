package com.example.demo.exception.response;


public class ExceptionResponse {
    private String message;
    private String code;

    public String getMessage() {
        return message;
    }

    public String getCode() {
        return code;
    }

    public ExceptionResponse(String message, String code) {
        this.message = message;
        this.code = code;
    }

}
