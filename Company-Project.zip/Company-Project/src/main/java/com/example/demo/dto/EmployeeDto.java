package com.example.demo.dto;

import java.math.BigDecimal;

public class EmployeeDto {
    private String fullName;
    private int age;
    private BigDecimal salary;
    private long department_id;

    public String getFullName() {
        return fullName;
    }

    public int getAge() {
        return age;
    }

    public BigDecimal getSalary() {
        return salary;
    }

    public long getDepartment_id() {
        return department_id;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSalary(BigDecimal salary) {
        this.salary = salary;
    }

    public void setDepartment_id(long department_id) {
        this.department_id = department_id;
    }
}
