package com.example.demo.dao.impl;

import com.example.demo.dao.inter.DepartmentDaoInter;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.exception.DepartmentNotFound;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class DepartmentDaoImpl implements DepartmentDaoInter {

    private final EntityManager em;

    public DepartmentDaoImpl(EntityManager em) {
        this.em = em;
    }

    @Override
    public Department getDepartmentById(Long id) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Department> cq = cb.createQuery(Department.class);

        Root<Department> department = cq.from(Department.class);
        Predicate idPredicate = cb.equal(department.get("id"), id);
        cq.where(idPredicate);

        TypedQuery<Department> query = em.createQuery(cq);

        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            throw new DepartmentNotFound("Department not found", "404");
        } finally {
            em.close();
        }

    }

    @Override
    public List<Employee> getEmployeeByDepartmentId(Long id) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Department> cq = cb.createQuery(Department.class);

        Root<Department> department = cq.from(Department.class);
        Predicate idPredicate = cb.equal(department.get("id"), id);
        cq.where(idPredicate);

        TypedQuery<Department> query = em.createQuery(cq);

        try {
            return query.getSingleResult().getEmployees();
        } catch (NoResultException e) {
            throw new DepartmentNotFound("Department not found", "404");
        } finally {
            em.close();
        }
    }


}
