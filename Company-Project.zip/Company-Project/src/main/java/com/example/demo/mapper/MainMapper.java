package com.example.demo.mapper;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;
import org.mapstruct.Mappings;

@Mapper(componentModel = "spring")
public interface MainMapper {
    @Mappings({
            @Mapping(target = "department.id", source = "employeeDTO.department_id"),
    })
    Employee dtoToEntity(EmployeeDto employeeDTO);

    @Mappings({
            @Mapping(target = "department_id", source = "department.id"),
    })
    EmployeeDto entityToDto(Employee employee);

    Department dtoToEntity(DepartmentDto departmentDto);

    DepartmentDto entityToDto(Department department);
}

