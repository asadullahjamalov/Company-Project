package com.example.demo.exception;

import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

import java.util.function.Supplier;

@Getter
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class EmployeeNotFound extends RuntimeException {
    String errorMessage;
    String code;
    public EmployeeNotFound(String errorMessage, String code) {
//        super("Employee Not Found");
        this.errorMessage = errorMessage;
        this.code = code;
    }

}