package com.example.demo.service.impl;

import com.example.demo.dao.inter.DepartmentDaoInter;
import com.example.demo.dto.DepartmentDto;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Department;
import com.example.demo.entity.Employee;
import com.example.demo.exception.DepartmentNotFound;
import com.example.demo.mapper.MainMapper;
import com.example.demo.repository.DepartmentRepo;
import com.example.demo.service.inter.DepartmentService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class DepartmentServiceImpl implements DepartmentService {

    private final DepartmentRepo departmentRepo;
    private final MainMapper mainMapper;
    private final DepartmentDaoInter departmentDaoInter;

    public DepartmentServiceImpl(DepartmentRepo departmentRepo,
                                 MainMapper mainMapper, DepartmentDaoInter departmentDaoInter) {
        this.departmentRepo = departmentRepo;
        this.mainMapper = mainMapper;
        this.departmentDaoInter = departmentDaoInter;
    }

    @Override
    public DepartmentDto createDepartment(DepartmentDto departmentDto) {
        Department department = departmentRepo.save(mainMapper.dtoToEntity(departmentDto));
        return mainMapper.entityToDto(department);
    }

    @Override
    public void deleteDepartmentById(long id) {
        if (departmentRepo.existsById(id)) {
            departmentRepo.deleteById(id);
        } else {
            throw new DepartmentNotFound("Department not found", "404");
        }
    }

    @Override
    public DepartmentDto updateDepartmentById(long id, DepartmentDto departmentDto) {
        Department updatedDepartment = departmentRepo.findById(id)
                .orElseThrow(() -> new DepartmentNotFound("Department not found", "404"));
        updatedDepartment.setName(mainMapper.dtoToEntity(departmentDto).getName());
        departmentRepo.save(updatedDepartment);
        return mainMapper.entityToDto(updatedDepartment);
    }

    @Override
    public DepartmentDto getDepartmentById(long id) {
//        Department department = departmentRepo.findById(id)
//                .orElseThrow(() -> new DepartmentNotFound("Department not found", "404"));

        return mainMapper.entityToDto(departmentDaoInter.getDepartmentById(id));
    }

    public List<DepartmentDto> getAllDepartments() {
        List<Department> departments = departmentRepo.findAll();
        return departments.stream()
                .map(mainMapper::entityToDto).collect(Collectors.toList());
    }

    @Override
    public List<EmployeeDto> getEmployeeByDepartmentId(long id) {
//        if (departmentRepo.findById(id).isPresent()) {
//            return departmentRepo.getById(id).getEmployees().stream()
//                    .map(mainMapper::entityToDto).collect(Collectors.toList());
//        } else {
//            throw new DepartmentNotFound("Department not found", "404");
//        }

        return departmentDaoInter.getEmployeeByDepartmentId(id).stream()
                .map(mainMapper::entityToDto).collect(Collectors.toList());
    }

    @Override
    public BigDecimal getAverageSalaryOfDepartment(long id) {
//        if (departmentRepo.findById(id).isPresent()) {
//            List<Employee> employees = departmentRepo.getById(id).getEmployees();
//            BigDecimal sumOfSalary = employees.stream().map(Employee::getSalary)
//                    .reduce(BigDecimal.ZERO, BigDecimal::add);
//            return sumOfSalary.divide(BigDecimal.valueOf(employees.size()), 3, RoundingMode.HALF_UP);
//        } else {
//            throw new DepartmentNotFound("Department not found", "404");
//        }

        List<Employee> employees = departmentDaoInter.getEmployeeByDepartmentId(id);
        BigDecimal sumOfSalary = employees.stream().map(Employee::getSalary)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        return sumOfSalary.divide(BigDecimal.valueOf(employees.size()), 3, RoundingMode.HALF_UP);

    }

    @Override
    public float getAverageAgeOfDepartment(long id) {
//        if (departmentRepo.findById(id).isPresent()) {
//            List<Employee> employees = departmentRepo.getById(id).getEmployees();
//            int sumOfAge = employees.stream().mapToInt(Employee::getAge).sum();
//            return sumOfAge / new Float(employees.size());
//        } else {
//            throw new DepartmentNotFound("Department not found", "404");
//        }


        List<Employee> employees = departmentDaoInter.getEmployeeByDepartmentId(id);
        int sumOfAge = employees.stream().mapToInt(Employee::getAge).sum();
        return sumOfAge / (float) employees.size();


    }
}
