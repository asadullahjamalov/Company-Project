package com.example.demo.dao.impl;

import com.example.demo.dao.inter.EmployeeDaoInter;
import com.example.demo.entity.Employee;
import com.example.demo.exception.EmployeeNotFound;
import org.springframework.stereotype.Repository;

import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Predicate;
import javax.persistence.criteria.Root;
import java.util.List;

@Repository
public class EmployeeDaoImpl implements EmployeeDaoInter {

    private final EntityManager em;

    public EmployeeDaoImpl(EntityManager em) {
        this.em = em;
    }

    @Override
    public Employee getEmployeeById(Long id) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);

        Root<Employee> employee = cq.from(Employee.class);
        Predicate idPredicate = cb.equal(employee.get("id"), id);
        cq.where(idPredicate);

        TypedQuery<Employee> query = em.createQuery(cq);

        try {
            return query.getSingleResult();
        } catch (NoResultException e) {
            throw new EmployeeNotFound("Employee not found", "404");
        } finally {
            em.close();
        }

    }

    @Override
    public List<Employee> getEmployeeByFullName(String fullName) {
        CriteriaBuilder cb = em.getCriteriaBuilder();
        CriteriaQuery<Employee> cq = cb.createQuery(Employee.class);

        Root<Employee> employee = cq.from(Employee.class);
        Predicate idPredicate = cb.equal(employee.get("fullName"), fullName);
        cq.where(idPredicate);

        TypedQuery<Employee> query = em.createQuery(cq);

        try {
            return query.getResultList();
        } catch (NoResultException e) {
            throw new EmployeeNotFound("Employee not found", "404");
        } finally {
            em.close();
        }

    }


}
