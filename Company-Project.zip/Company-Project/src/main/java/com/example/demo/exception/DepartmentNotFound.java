package com.example.demo.exception;


import lombok.Getter;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@Getter
@ResponseStatus(value = HttpStatus.NOT_FOUND)
public class DepartmentNotFound extends RuntimeException {
    String errorMessage;
    String code;

    public DepartmentNotFound(String errorMessage, String code) {
        super("Department Not Found");
        this.errorMessage = errorMessage;
        this.code = code;
    }

}
