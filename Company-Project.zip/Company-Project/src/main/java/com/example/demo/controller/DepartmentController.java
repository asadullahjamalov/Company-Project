package com.example.demo.controller;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.service.inter.DepartmentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.util.List;

@RestController
@RequestMapping("/api/v1/departments")
public class DepartmentController {

    private static final Logger log = LoggerFactory.getLogger(DepartmentController.class);
    private final DepartmentService departmentService;

    public DepartmentController(DepartmentService departmentService) {
        this.departmentService = departmentService;
    }

    @PostMapping
    public ResponseEntity<DepartmentDto> createDepartment(@RequestBody DepartmentDto departmentDto) {
        log.info("Department was created");
        return new ResponseEntity<>(departmentService.createDepartment(departmentDto), HttpStatus.CREATED);
    }

    @PutMapping("/{departmentId}")
    public ResponseEntity<DepartmentDto> updateDepartment(@PathVariable Long departmentId,
                                                          @RequestBody DepartmentDto departmentDto) {
        log.info("Department was updated");
        return new ResponseEntity<>(departmentService.updateDepartmentById(departmentId, departmentDto), HttpStatus.OK);
    }

    @GetMapping("/{departmentId}")
    public ResponseEntity<DepartmentDto> getDepartmentById(@PathVariable Long departmentId) {
        log.info("Getting department by id");
        return new ResponseEntity<>(departmentService.getDepartmentById(departmentId), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<DepartmentDto>> getAllDepartments() {
        log.info("Getting all departments");
        return new ResponseEntity<>(departmentService.getAllDepartments(), HttpStatus.OK);
    }

    @DeleteMapping("/{departmentId}")
    public ResponseEntity<Void> deleteDepartment(@PathVariable Long departmentId) {
        log.info("Deleting department by id");
        departmentService.deleteDepartmentById(departmentId);
        return new ResponseEntity<>(HttpStatus.OK);
    }

    @GetMapping("/{departmentId}/employees")
    public ResponseEntity<List<EmployeeDto>> getEmployeesByDepartmentId(@PathVariable Long departmentId) {
        log.info("Getting employees by department id");
        return new ResponseEntity<>(departmentService.getEmployeeByDepartmentId(departmentId), HttpStatus.OK);
    }

    @GetMapping("/{departmentId}/average-age")
    public ResponseEntity<Float> getDepartmentAverageAgeById(@PathVariable Long departmentId) {
        log.info("Getting average age of employees by department id");
        return new ResponseEntity<>(departmentService.getAverageAgeOfDepartment(departmentId), HttpStatus.OK);
    }

    @GetMapping("/{departmentId}/average-salary")
    public ResponseEntity<BigDecimal> getDepartmentAverageSalaryById(@PathVariable Long departmentId) {
        log.info("Getting average salary of employees by department id");
        return new ResponseEntity<>(departmentService.getAverageSalaryOfDepartment(departmentId), HttpStatus.OK);
    }
}
