package com.example.demo.service.inter;

import com.example.demo.dto.DepartmentDto;
import com.example.demo.dto.EmployeeDto;

import java.math.BigDecimal;
import java.util.List;

public interface DepartmentService {

    DepartmentDto createDepartment(DepartmentDto departmentDto);

    void deleteDepartmentById(long id);

    DepartmentDto updateDepartmentById(long id, DepartmentDto departmentDto);

    DepartmentDto getDepartmentById(long id);

    List<DepartmentDto> getAllDepartments();

    List<EmployeeDto> getEmployeeByDepartmentId(long id);

    BigDecimal getAverageSalaryOfDepartment(long id);

    float getAverageAgeOfDepartment(long id);
}
