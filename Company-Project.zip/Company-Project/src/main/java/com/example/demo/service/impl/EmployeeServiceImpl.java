package com.example.demo.service.impl;

import com.example.demo.dao.inter.EmployeeDaoInter;
import com.example.demo.dto.EmployeeDto;
import com.example.demo.entity.Employee;
import com.example.demo.exception.DepartmentNotFound;
import com.example.demo.exception.EmployeeNotFound;
import com.example.demo.mapper.MainMapper;
import com.example.demo.repository.DepartmentRepo;
import com.example.demo.repository.EmployeeRepo;
import com.example.demo.service.inter.EmployeeService;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class EmployeeServiceImpl implements EmployeeService {

    private final EmployeeRepo employeeRepo;
    private final DepartmentRepo departmentRepo;
    private final MainMapper mainMapper;
    private final EmployeeDaoInter employeeDaoInter;

    public EmployeeServiceImpl(EmployeeRepo employeeRepo, DepartmentRepo departmentRepo,
                               MainMapper mainMapper, EmployeeDaoInter employeeDaoInter) {
        this.employeeRepo = employeeRepo;
        this.departmentRepo = departmentRepo;
        this.mainMapper = mainMapper;
        this.employeeDaoInter = employeeDaoInter;
    }

    @Override
    public EmployeeDto createEmployee(EmployeeDto employeeDto) {
        if (departmentRepo.findById(employeeDto.getDepartment_id()).isPresent()) {
            employeeRepo.save(mainMapper.dtoToEntity(employeeDto));
        } else {
            throw new DepartmentNotFound("Department not found", "404");
        }
        return employeeDto;
    }

    @Override
    public void deleteEmployeeById(long id) {
        if (employeeRepo.existsById(id)) {
            employeeRepo.deleteById(id);
        } else {
            throw new EmployeeNotFound("Employee not found", "404");
        }
    }

    @Override
    public EmployeeDto updateEmployeeById(long id, EmployeeDto employeeDto) {
        Employee updatedEmployee = employeeRepo.findById(id)
                .orElseThrow(() -> new EmployeeNotFound("Employee not found", "404"));
        Employee employee = mainMapper.dtoToEntity(employeeDto);
        updatedEmployee.setFullName(employee.getFullName());
        updatedEmployee.setAge(employee.getAge());
        updatedEmployee.setSalary(employee.getSalary());
        if (departmentRepo.findById(employee.getDepartment().getId()).isPresent()) {
            updatedEmployee.setDepartment(employee.getDepartment());
        } else {
            throw new DepartmentNotFound("Department not found", "404");
        }
        employeeRepo.save(updatedEmployee);
        return employeeDto;
    }

    @Override
    public EmployeeDto getEmployeeById(long id) {
//        Employee employee = employeeRepo.findById(id)
//                .orElseThrow(() -> new EmployeeNotFound("Employee not found", "404"));
//        return mainMapper.entityToDto(employee);

        return mainMapper.entityToDto(employeeDaoInter.getEmployeeById(id));
    }

    @Override
    public List<EmployeeDto> getAllEmployees() {
        return employeeRepo.findAll().stream().map(mainMapper::entityToDto)
                .collect(Collectors.toList());
    }

    @Override
    public List<EmployeeDto> getEmployeesByFullName(String fullName) {
//        return employeeRepo.findEmployeesByFullName(fullName).stream().map(mainMapper::entityToDto)
//                .collect(Collectors.toList());

        return employeeDaoInter.getEmployeeByFullName(fullName).stream().map(mainMapper::entityToDto)
                .collect(Collectors.toList());
    }


}
