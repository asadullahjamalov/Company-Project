package com.example.demo.exception;

import com.example.demo.exception.response.ExceptionResponse;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@RestControllerAdvice
public class RestExceptionHandler extends ResponseEntityExceptionHandler {

    @ExceptionHandler(value = {DepartmentNotFound.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ExceptionResponse handleDepartmentNotFoundException(DepartmentNotFound ex) {
        return new ExceptionResponse(ex.errorMessage, ex.code);
    }

    @ExceptionHandler(value = {EmployeeNotFound.class})
    @ResponseStatus(HttpStatus.NOT_FOUND)
    public ExceptionResponse handleEmployeeNotFoundException(EmployeeNotFound ex) {
        return new ExceptionResponse(ex.errorMessage, ex.code);
    }

    @ExceptionHandler(value = {Exception.class})
    @ResponseStatus(HttpStatus.INTERNAL_SERVER_ERROR)
    public ExceptionResponse handleUnexpectedError(Exception ex) {
        return new ExceptionResponse(ex.getMessage(),"Unexpected error");
    }



}
