package com.example.demo.service.inter;

import com.example.demo.dto.EmployeeDto;

import java.util.List;

public interface EmployeeService {
    EmployeeDto createEmployee(EmployeeDto employeeDto);

    void deleteEmployeeById(long id);

    EmployeeDto updateEmployeeById(long id, EmployeeDto employeeDto);

    EmployeeDto getEmployeeById(long id);

    List<EmployeeDto> getAllEmployees();

    List<EmployeeDto> getEmployeesByFullName(String fullName);

}
