package com.example.demo.dao.inter;

import com.example.demo.entity.Employee;

import java.util.List;

public interface EmployeeDaoInter {

    Employee getEmployeeById(Long id);

    List<Employee> getEmployeeByFullName(String fullName);
}
