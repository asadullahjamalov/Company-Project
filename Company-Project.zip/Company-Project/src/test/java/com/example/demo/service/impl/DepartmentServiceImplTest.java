package com.example.demo.service.impl;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class DepartmentServiceImplTest {

    @Test
    void createDepartment() {
    }

    @Test
    void deleteDepartmentById() {
    }

    @Test
    void updateDepartmentById() {
    }

    @Test
    void getDepartmentById() {
    }

    @Test
    void getAllDepartments() {
    }

    @Test
    void getEmployeeByDepartmentId() {
    }

    @Test
    void getAverageSalaryOfDepartment() {
    }

    @Test
    void getAverageAgeOfDepartment() {
    }
}