//package com.example.demo.service.impl;
//
//import com.example.demo.dto.DepartmentDto;
//import com.example.demo.dto.EmployeeDto;
//import com.example.demo.entity.Department;
//import com.example.demo.entity.Employee;
//import com.example.demo.mapper.MainMapper;
//import com.example.demo.repository.DepartmentRepo;
//import com.example.demo.repository.EmployeeRepo;
//import org.junit.Ignore;
//import org.junit.jupiter.api.AfterEach;
//import org.junit.jupiter.api.BeforeEach;
//import org.junit.jupiter.api.Test;
//import org.mockito.Mock;
//import org.mockito.MockitoAnnotations;
//import org.springframework.beans.factory.annotation.Autowired;
//
//import static org.mockito.Mockito.verify;
//
//import java.util.Arrays;
//import java.util.List;
//
//import static org.assertj.core.api.AssertionsForClassTypes.assertThat;
//import static org.junit.jupiter.api.Assertions.*;
//import static org.mockito.Mockito.when;
//
////@DataJpaTest
////@ExtendWith(MockitoExtension.class)
//class EmployeeServiceImplTest {
//
//    @Mock
//    private EmployeeRepo employeeRepo;
//    @Mock
//    private DepartmentRepo departmentRepo;
//    @Autowired
//    private MainMapper mainMapper;
//
//    private AutoCloseable autoCloseable;
//    private EmployeeServiceImpl underTest;
//
//
//    @BeforeEach
//    void setUp() {
//        autoCloseable = MockitoAnnotations.openMocks(this);
//        underTest = new EmployeeServiceImpl(employeeRepo, departmentRepo);
//    }
//
//    @AfterEach
//    void tearDown() throws Exception {
//        autoCloseable.close();
//    }
//
//    @Ignore
//    @Test
//    void createEmployee() {
//    }
//
//    @Ignore
//    @Test
//    void deleteEmployeeById() {
//    }
//
//    @Test
//    void updateEmployeeById() {
//        Department department = new Department();
//        department.setId(1l);
//
//        Employee employee1 = new Employee();
//        employee1.setId(1l);
//        employee1.setDepartment(department);
//        employeeRepo.save(employee1);
//        EmployeeDto employeeDto1 = mainMapper.entityToDto(employee1);
//
//        when(underTest.getEmployeeById(1l)).thenReturn(employeeDto1);
//
//
//        underTest.updateEmployeeById(1l, employeeDto1);
//        Employee employee = verify(employeeRepo).findById(1l).get();
//        verify(mainMapper).dtoToEntity(employeeDto1);
//        verify(employeeRepo).save(employee);
//    }
//
//    @Test
//    void getEmployeeById() {
//        Department department = new Department();
//        department.setId(1l);
//        departmentRepo.save(department);
//
//
//        Employee employee1 = new Employee();
//        employee1.setId(1l);
//        employee1.setFullName("ssdffdsd");
//        employee1.setDepartment(department);
//        employeeRepo.save(employee1);
//
//        System.out.printf(employee1.getFullName());
//
//
////        System.out.println("---------"+underTest.getEmployeeById(1l).getFullName());
//        EmployeeDto employeeDto1 = mainMapper.entityToDto(employee1);
//
//        System.out.printf(employeeDto1.getFullName());
//
//        when(underTest.getEmployeeById(employee1.getId())).thenReturn(employeeDto1);
////                .thenThrow(new EmployeeNotFound("Employee not found", "404"));
//
////        underTest.getEmployeeById(1l);
////        verify(employeeRepo).findById(1l)
////                .orElseThrow(() -> new EmployeeNotFound("Employee not found", "404"));
//    }
//
////    @Test
////    void getEmployeeByIdReturnsEmployeeNotFound() {
////        when(underTest.getEmployeeById(2l)).thenAnswer(new ExceptionResponse("Employee not found", "404")).;
////
////        underTest.getEmployeeById(1l);
////        verify(employeeRepo).findById(1l);
////    }
//
//    @Test
//    void getAllEmployees() {
//        Department department = new Department();
//        department.setId(1l);
//        departmentRepo.save(department);
//
//        Employee employee1 = new Employee();
//        employee1.setId(1l);
//        employee1.setDepartment(department);
//        employeeRepo.save(employee1);
//        EmployeeDto employeeDto1 = mainMapper.entityToDto(employee1);
//
//        Employee employee2 = new Employee();
//        employee2.setId(2l);
//        employee2.setDepartment(department);
//        employeeRepo.save(employee2);
//        EmployeeDto employeeDto2 = mainMapper.entityToDto(employee2);
//
//        Employee employee3 = new Employee();
//        employee3.setId(3l);
//        employee3.setDepartment(department);
//        employeeRepo.save(employee3);
//        EmployeeDto employeeDto3 = mainMapper.entityToDto(employee3);
//
//        when(underTest.getAllEmployees()).thenReturn(Arrays.asList(employeeDto1, employeeDto2, employeeDto3));
//
//        List<EmployeeDto> employeeDtoList = underTest.getAllEmployees();
//        assertEquals(employeeDtoList.size(), 3);
//        verify(employeeRepo).findAll();
//    }
//
//    @Ignore
//    @Test
//    void getEmployeesByFullName() {
//    }
//}